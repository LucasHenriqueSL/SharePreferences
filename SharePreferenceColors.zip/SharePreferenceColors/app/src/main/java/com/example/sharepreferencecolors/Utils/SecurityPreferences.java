package com.example.sharepreferencecolors.Utils;
import android.content.Context;
import android.content.SharedPreferences;


public class SecurityPreferences {

    private final SharedPreferences mSharedPreferences;

    public SecurityPreferences(Context context) {
        this.mSharedPreferences = context.getSharedPreferences("cores",Context.MODE_PRIVATE);
    }
    public void StoreString(String chave, String valor){
        this.mSharedPreferences.edit().putString(chave,valor).apply();
    }
    public String getStoreString(String chave){
        return this.mSharedPreferences.getString(chave, "Default");
    }
}
