package com.example.sharepreferencecolors;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import  com.example.sharepreferencecolors.Utils.SecurityPreferences;
import static android.graphics.Color.parseColor;

public class MainActivity extends AppCompatActivity {
    private SecurityPreferences mSecurityPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.mSecurityPreferences = new SecurityPreferences(this);
        View view = findViewById(R.id.view);
        ActionBar bar = getSupportActionBar();
        if(mSecurityPreferences.getStoreString("barcolor") == "Default"){
            view.setBackgroundColor(parseColor("#ffffff"));
        }else{
            view.setBackgroundColor(parseColor(mSecurityPreferences.getStoreString("backgroundcolor")));
            bar.setBackgroundDrawable(new ColorDrawable(parseColor(mSecurityPreferences.getStoreString("barcolor"))));
            getWindow().setStatusBarColor(parseColor(mSecurityPreferences.getStoreString("barcolor")));
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.layout.activity_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if(id == R.id.action_azul){
            mSecurityPreferences.StoreString("backgroundcolor", "#0010f2");
            mSecurityPreferences.StoreString("barcolor", "#0010f2");
            String backColor = mSecurityPreferences.getStoreString("backgroundcolor");
            String outrasColor = mSecurityPreferences.getStoreString("barcolor");

            Toast.makeText(this,"Cor atualizada",Toast.LENGTH_LONG).show();

            View view = findViewById(R.id.view);
            view.setBackgroundColor(parseColor(backColor));

            ActionBar bar = getSupportActionBar();
            bar.setBackgroundDrawable(new ColorDrawable(parseColor(outrasColor)));
            getWindow().setStatusBarColor(parseColor(outrasColor));

        }else if(id == R.id.action_amarelo){
            mSecurityPreferences.StoreString("backgroundcolor", "#ffc71f");
            mSecurityPreferences.StoreString("barcolor", "#ffc71f");
            String backColor = mSecurityPreferences.getStoreString("backgroundcolor");
            String outrasColor = mSecurityPreferences.getStoreString("barcolor");
            Toast.makeText(this,"Cor atualizada",Toast.LENGTH_LONG).show();

            View view = findViewById(R.id.view);
            view.setBackgroundColor(parseColor(backColor));

            ActionBar bar = getSupportActionBar();
            bar.setBackgroundDrawable(new ColorDrawable(parseColor(outrasColor)));
            getWindow().setStatusBarColor(parseColor(outrasColor));

        }
        return super.onOptionsItemSelected(item);




    }
}